/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dni;

/**
 *
 * @author usutarde
 * @version 1.0
 * @since 2025-04-09
 */
public class Dni {

    /**
     * Número del DNI (sin la letra).
     */
    private int numero;

    /**
     * Letra del DNI.
     */
    private char letra;

    /**
     * Es el constructor del DNI con un número y una letra como parámetros.
     * Primero, valida que el número y la letra sean correctos según el formato del DNI español.
     *
     * @param numero es el número del DNI (hasta 8 cifras)
     * @param letra  es la letra del DNI
     * @throws IllegalArgumentException lanza la excepción si el número o la letra no son válidos
     */
    public Dni(int numero, char letra) {
        if (!esNumeroValido(numero)) {
            throw new IllegalArgumentException("El número del DNI no es válido");
        }
        if (!esLetraValida(numero, letra)) {
            throw new IllegalArgumentException("La letra del DNI no es válida");
        }

        this.numero = numero;
        this.letra = letra;
    }

    /**
     * Verifica si el número del DNI es válido.
     * Debe ser un número positivo (mayor que 0) con un máximo de 8 dígitos.
     *
     * @param numero es el número del DNI
     * @return devuelve true si el número es válido y devuelve false en caso contrario
     */
    private boolean esNumeroValido(int numero) {
        return numero > 0 && String.valueOf(numero).length() <= 8;
    }

    /**
     * Verifica si la letra del DNI es válida, según el número dado.
     * La letra se calcula usando el número y comparando con la letra proporcionada.
     *
     * @param numero es el número del DNI
     * @param letra es la letra a validar
     * @return devuelve true si la letra es válida y devuelve false en caso contrario
     */
    private boolean esLetraValida(int numero, char letra) {
        if (!Character.isLetter(letra)) {
            return false;
        }

        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        int indice = numero % 23;
        char letraCalculada = letras.charAt(indice);

        return Character.toUpperCase(letra) == letraCalculada;
    }

    /**
     * Devuelve el número del DNI.
     *
     * @return el número del DNI
     */
    public int getNumero() {
        return numero;
    }

    /**
     * Cambia el número del DNI.
     *
     * @param numero el nuevo número del DNI
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * Devuelve la letra del DNI.
     *
     * @return la letra del DNI
     */
    public char getLetra() {
        return letra;
    }

    /**
     * Cambia la letra del DNI.
     *
     * @param letra la nueva letra del DNI
     */
    public void setLetra(char letra) {
        this.letra = letra;
    }

    /**
     * Devuelve una cadena compuesta por el DNI en formato de 8 dígitos y letra.
     *
     * @return una cadena con el formato del DNI
     */
    @Override
    public String toString() {
        return String.format("%08d%c", numero, letra);
    }
}