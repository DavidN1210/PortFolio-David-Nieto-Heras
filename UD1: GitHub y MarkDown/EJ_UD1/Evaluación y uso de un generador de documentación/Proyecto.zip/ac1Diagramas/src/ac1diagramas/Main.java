/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ac1diagramas;

import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import persona.Persona;

/**
 *
 * @author usutarde
 * @version 1.0
 * @since 2025-04-09
 */
public class Main {

    /**
     * Método principal de la aplicación.
     * Aquí dentro de un try-catch se crea una nueva persona con sus respectivos datos (nombre, apellidos y dni)
     * y luego los muestra por consola
     *
     * @param args los argumentos de línea de comandos (no se utilizan en este programa)
     */
    public static void main(String[] args) {
        
        try {
            // Se crea una persona de ejemplo con nombre, apellidos, fecha de nacimiento y DNI
            Persona p1 = new Persona("David", "Nieto", "Heras", "10/12/2006", 12345678, 'Z');
            
            // Se muestra la información completa de la persona en la consola
            System.out.println(p1.toString());
            
        } catch (ParseException ex) {
            // En caso de error al parsear la fecha, se registra en el logger
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
