package persona;

import dni.Dni;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;

/**
 *
 * @author usutarde
 * @version 1.0
 * @since 2025-04-09
 */
public class Persona {
    
    /** Nombre de la persona. */
    private String nombre;
    
    /** Primer apellido de la persona. */
    private String apellido1;
    
    /** Segundo apellido de la persona. */
    private String apellido2;
    
    /** Fecha de nacimiento de la persona. */
    private Date fechaNacimiento;
    
    /** DNI de la persona. */
    private Dni dni;

    /**
     * Constructor de la clase {@code Persona}.
     * 
     * @param nombre nombre de la persona
     * @param apellido1 primer apellido de la persona
     * @param apellido2 segundo apellido de la persona
     * @param fechaNacimientoStr fecha de nacimiento
     * @param numeroDni número del DNI
     * @param letraDni letra del DNI
     * @throws ParseException si la fecha no cumple con el formato esperado
     */
    public Persona(String nombre, String apellido1, String apellido2, String fechaNacimientoStr, int numeroDni, char letraDni) 
             throws ParseException
    {
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        setFechaNacimiento(fechaNacimientoStr);
        this.dni = new Dni (numeroDni, letraDni);
    }

    /**
     * Obtiene el nombre de la persona.
     * 
     * @return nombre de la persona
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece o cambia el nombre de la persona.
     * 
     * @param nombre nuevo nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene el primer apellido de la persona.
     * 
     * @return primer apellido
     */
    public String getApellido1() {
        return apellido1;
    }

    /**
     * Establece o cambia el primer apellido de la persona.
     * 
     * @param apellido1 nuevo primer apellido
     */
    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    /**
     * Obtiene el segundo apellido de la persona.
     * 
     * @return segundo apellido
     */
    public String getApellido2() {
        return apellido2;
    }

    /**
     * Establece o cambia el segundo apellido de la persona.
     * 
     * @param apellido2 nuevo segundo apellido
     */
    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    /**
     * Obtiene el objeto DNI de la persona.
     * 
     * @return DNI de la persona
     */
    public Dni getDni() {
        return dni;
    }

    /**
     * Establece o cambia el objeto DNI de la persona.
     * 
     * @param dni nuevo DNI
     */
    public void setDni(Dni dni) {
        this.dni = dni;
    }
    
    /**
     * Obtiene la fecha de nacimiento
     * 
     * @return la fecha de nacimiento 
     */
    public String getFechaNacimiento() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        return formatoFecha.format(fechaNacimiento);
    }

    /**
     * Establece o cambia la fecha de nacimiento a partir de una cadena.
     * 
     * @param fechaEntra fecha como parámetro
     * @throws ParseException si la fecha no cumple con el formato esperado
     */
    public void setFechaNacimiento(String fechaEntra) throws ParseException {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy"); 
        this.fechaNacimiento = formatoFecha.parse(fechaEntra);
    }
    
    /**
     * Calcula la edad actual de la persona
     * a partir de la fecha de nacimiento.
     * 
     * @return edad en años
     */
    public int getEdad(){
        LocalDate fechaNac = new java.sql.Date(fechaNacimiento.getTime()).toLocalDate();
        LocalDate hoy = LocalDate.now();
        
        return Period.between(fechaNac, hoy).getYears();
    }

    /**
     * Devuelve todos los datos de la persona,
     * el nombre completo, edad y DNI.
     * 
     * @return cadena con los datos de la persona
     */
    @Override
    public String toString() {
        return nombre + " " + apellido1 + " " + apellido2 + " " + getEdad() + " " + dni.toString();
    }
    
}
